A Pen created at CodePen.io. You can find this one at http://codepen.io/jcoulterdesign/pen/azepmX.

 Just trying to do some login animations. Buggy on Firefox, fine in Chrome. Still need to tidy up and Optimize